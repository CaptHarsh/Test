﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CxCE_Demo
{
    class Constants
    {
        public static string DB_PASSWORD = "Checkmarx123!";
    }
}
